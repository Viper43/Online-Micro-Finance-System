function addFields() {
    document.getElementById("add_rates").style.display = 'flex';
    document.getElementById("B").style.display = 'block'
}