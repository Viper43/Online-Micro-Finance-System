<?php 
    $min_balance = 2000;        //Define minimum balance to be maintained for an account
?>